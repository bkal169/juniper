﻿# Grant Proposal – Heart of Juniper
**Funder:** {{Funder}} | **Stage:** {{Stage}} | **Program:** {{Program}}

## Summary
One-paragraph case for support.

## Need
Local data + stories.

## Program & Outcomes
Cohort size, curriculum, certifications, placements, evaluation.

## Budget
Ask: ${{Ask ($)}} | Co-funders | In-kind.

## Org Capacity
Team, partners, governance.

## Appendix
Letters, IRS, financials.
