﻿# Listing – Command Sheet
**Address:** {{Address}}
**Client:** [[{{CRM Contact}}]]
**Source:** {{Source}} | **Lead Type:** {{Lead Type}}
**Stage:** {{Stage}} | **Owner:** {{Owner}}

## 1) The Plan (Here’s what I’m going to do…)
- CMA → Pricing Strategy
- Pro photos/3D → MLS → Sign + Lockbox
- Neighbor invites → Open House #1–2
- Feedback → Offers → Escrow → Close

## 2) Scripts
{{Scripts}}

## 3) Objections
{{Objections}}

## 4) Checklist
→ See related **Checklist** tasks.

## 5) Notes
{{Notes}}
