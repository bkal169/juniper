﻿# Thank You – {{Donor}}

Dear {{Donor}},

Thank you for your generous support of Heart of Juniper. Your gift accelerates mentorship, emotional intelligence, and financial literacy for our youth.

With gratitude,
Alan Augustin
