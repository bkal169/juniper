﻿(…same Make blueprints as bash version…)
