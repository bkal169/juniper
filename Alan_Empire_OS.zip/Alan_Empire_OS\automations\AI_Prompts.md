﻿(…same AI prompts as bash version…)
