﻿# Daily Brief – {{Date}}

## Market Snapshot
•

## Script of the Day
•

## Top 10 Follow-ups
1)
…

## Calendar
•
