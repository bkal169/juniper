﻿# Alan Empire OS – Import Guide
(…same text as in bash README…)
