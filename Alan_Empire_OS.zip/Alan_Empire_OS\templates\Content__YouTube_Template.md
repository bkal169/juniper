﻿# Video Script
**Channel:** {{Channel}} | **Status:** {{Status}} | **Publish:** {{Publish Date}}

**Hook (0–10s):**
**Intro (10–30s):**
**Value Sections:**
1)
2)
3)
**CTA:** Subscribe | Free guide | Book a call
