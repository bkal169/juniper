﻿# Buttons & Views
(Home dashboard linked views: Deals, CRM, Content, KPI Snapshot, Daily_Briefs, Automation_Log.
Buttons: New Lead, Spawn Full Listing Checklist, Generate Script Request.)
